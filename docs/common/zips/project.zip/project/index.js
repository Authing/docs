var getRawBody = require('raw-body')
var bcryptjs = require('bcryptjs')

const encryptPassword = password => {
    return bcryptjs.hashSync(password, bcryptjs.genSaltSync())
}

/**
 *
 * @param {String} password 明文密码
 * @param {String} encryptedPassword 密文密码
 */
const comparePassword = (password, encryptedPassword) => {
  return bcryptjs.compareSync(password, encryptedPassword)
}

module.exports.encrypt = function(request, response, context) {
  // get request body
  getRawBody(request, function(err, body) {
    const queries = request.queries
    const password = queries.password

    if (!password) {
      response.setStatusCode(500)
      response.setHeader('content-type', 'application/json')
      response.send(
        JSON.stringify(
          {
            message: 'Please provide password via url query',
          },
          null,
          4
        )
      )
    }

    const respBody = {
      password: encryptPassword(password), // 在此加密密码
    }

    response.setStatusCode(200)
    response.setHeader('content-type', 'application/json')
    response.send(JSON.stringify(respBody, null, 4))
  })
}

module.exports.validate = function(request, response, context) {
  // get request body
  getRawBody(request, function(err, body) {
    const queries = request.queries
    const password = queries.password
    const encryptedPassword = queries.encryptedPassword

    if (!password) {
      response.setStatusCode(500)
      response.setHeader('content-type', 'application/json')
      response.send(
        JSON.stringify(
          {
            message: 'Please provide password via url query',
          },
          null,
          4
        )
      )
    }

    const respBody = {
      isValid: comparePassword(password, encryptedPassword), // 在此校验密码
    }

    response.setStatusCode(200)
    response.setHeader('content-type', 'application/json')
    response.send(JSON.stringify(respBody, null, 4))
  })
}
